from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import time

options = Options()
options.add_argument("--start-maximized")

service = Service("C:/Users/DELL/Desktop/SeleniumTest/chromedriver-win64/chromedriver.exe")
driver = webdriver.Chrome(service=service, options=options)
driver.implicitly_wait(10)

BASE_URL = "https://practicetestautomation.com/practice-test-login/"

def test_positive_login():
    driver.get(BASE_URL)
    driver.find_element(By.ID, "username").send_keys("student")
    driver.find_element(By.ID, "password").send_keys("Password123")
    driver.find_element(By.ID, "submit").click()
    time.sleep(2)
    assert "Logged In Successfully" in driver.page_source
    print("Positive Login Test Passed")

def test_negative_login():
    driver.get(BASE_URL)
    driver.find_element(By.ID, "username").send_keys("wronguser")
    driver.find_element(By.ID, "password").send_keys("wrongpass")
    driver.find_element(By.ID, "submit").click()
    time.sleep(2)
    assert "Your username is invalid!" in driver.page_source
    print("Negative Login Test Passed")

def test_navigation():
    driver.get(BASE_URL)
    driver.find_element(By.ID, "username").send_keys("student")
    driver.find_element(By.ID, "password").send_keys("Password123")
    driver.find_element(By.ID, "submit").click()
    time.sleep(2)
    driver.find_element(By.LINK_TEXT, "Log out")
    print("Navigation Test Passed")

def test_logout():
    driver.get(BASE_URL)
    driver.find_element(By.ID, "username").send_keys("student")
    driver.find_element(By.ID, "password").send_keys("Password123")
    driver.find_element(By.ID, "submit").click()
    time.sleep(2)
    driver.find_element(By.LINK_TEXT, "Log out").click()
    time.sleep(2)
    assert "Practice" in driver.title
    print("Logout Test Passed")

try:
    test_positive_login()
    test_negative_login()
    test_navigation()
    test_logout()
    print("ALL TESTS COMPLETED SUCCESSFULLY")
finally:
    driver.quit()